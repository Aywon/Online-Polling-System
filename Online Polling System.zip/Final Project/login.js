

//document.querySelector("button").addEventListener("click",myFunction);


function myFunction(){
    

        alert("Fill up all the fields");



}





