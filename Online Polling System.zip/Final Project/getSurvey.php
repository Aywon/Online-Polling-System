<?php
session_start();

$connection = mysqli_connect("localhost", "root","", "survey");
if(isset($_SESSION['userid'])) $userid = $_SESSION['userid'];
else $userid = "0";
$sql = "SELECT * FROM surveys where userid=$userid";
$result = mysqli_query($connection, $sql);
//Get the data
$identifiers = mysqli_fetch_all($result, MYSQLI_ASSOC);
echo json_encode($identifiers);

?>