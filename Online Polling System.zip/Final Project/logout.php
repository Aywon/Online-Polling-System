<?php
session_start();
if(isset($_SESSION['userid'])) {
    session_destroy();
    echo "You have been logged out!";
    echo "<a href='index.php'>Home</a>";
}
else {
    header("location: index.php");
}
?>