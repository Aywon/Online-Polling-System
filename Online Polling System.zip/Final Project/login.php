<?php
$db = mysqli_connect("localhost","root", "","survey");
if(isset($_POST['submit_button'])){
   $email=$_POST['email']; 
   $password=$_POST['password'];
  
       if(!empty($_POST['rememberme'])){
           setcookie('email',$email,time()+60*60*7);
           setcookie('password',$password,time()+60*60*7);
       }
   
    session_start();
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $sql = "SELECT * FROM people WHERE email='$email' AND password='$password'";
    $verify = mysqli_query($db, $sql);

    if(mysqli_num_rows($verify)==1){
    $row= mysqli_fetch_assoc($verify);
    $_SESSION['userid']=$row['id'];
    $_SESSION['username']=$row['name'];
    $_SESSION['phone'] = $row['phone'];
    $_SESSION['address'] = $row['address'];
    $_SESSION['email']=$email;
    $_SESSION['password']=$password;
    header("location:index.php");
    }else{
        ?>
        <script>
           
        alert("Incorrect email/password combination. Check and proceed again.");
    
        </script>
        <?php
       // echo "Incorrect email/password combination. Check and proceed again.";


    }
    
}
    


?>





<!DOCTYPE html>
<html>
    <head>
        <title>PROJECT</title>
        <link rel="stylesheet" type="text/css" href="login.css">
        <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">-->
        <h1 >WELCOME TO THE PORTAL</h1>
        <!--<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Final Project</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
  <ul class="navbar-nav ml-auto">
             <li class="nav-item"> <a class="nav-link" herf='#'>About us</a></li>
             <li class="nav-item"> <a class="nav-link" herf='#'>Help centra</a></li>
             <li class="nav-item"> <a class="nav-link" herf='#'>Contact</a></li>
        </ul>
  
  
  </div>
        
        
        
        </nav>-->
    </head>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<script src='login.js'></script>
    <body>
        
        <fieldset>
        <legend align="center"><h2>"LOGIN"</h2></legend>
        <form method="post" action="login.php">
           
            <table align="center">
                
               
                <tr>
                    <td>EMAIL:</td>
                    <td><input type="email" name="email" required></td>
                </tr>
                <tr>
                    <td>PASSWORD:</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    
                    <td><input name="rememberme" id="remember" type="checkbox" value="1" required>
                <label>Remember me</label></td>
                </tr>
                <tr>
                    
                    <td ><button><input type="submit" name="submit_button" value="Login" required></button></td>
                </tr>
                <td><a href="signup.php">Sign Up</a></td>
                
                <script src="login.js"></script>
                    
               
                
    </fieldset>  
        </form>
       
        
        
        
    </body>    
</html>